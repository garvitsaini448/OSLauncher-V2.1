package com.example.oslauncher

import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.*
import android.net.*
import android.os.*
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class WeatherState(
    val temperature: String = "--°",
    val location: String = "Weather unavailable",
    val description: String = "",
    val loading: Boolean = false
)

data class StatusState(
    val time: String = "--:--",
    val date: String = "",
    val downBytesPerSec: Long = 0,
    val upBytesPerSec: Long = 0,
    val wifiConnected: Boolean = false,
    val bluetoothOn: Boolean = false,
    val batteryPercent: Int = 0,
    val charging: Boolean = false,
    val weather: WeatherState = WeatherState()
)

class StatusViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx = application.applicationContext
    private val connectivity = ctx.getSystemService(ConnectivityManager::class.java)
    private val _state = MutableStateFlow(StatusState())
    val state: StateFlow<StatusState> = _state.asStateFlow()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = applyBattery(intent)
    }
    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
            _state.update { it.copy(bluetoothOn = s == BluetoothAdapter.STATE_ON) }
        }
    }
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { refreshNetworkState() }
        override fun onLost(network: Network) { refreshNetworkState() }
    }

    init {
        val initialBattery = ContextCompat.registerReceiver(
            ctx, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        initialBattery?.let { applyBattery(it) }

        ContextCompat.registerReceiver(
            ctx, bluetoothReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        runCatching {
            connectivity?.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                networkCallback
            )
        }
        refreshNetworkState()
        startClockLoop()
        refreshWeather()
    }

    private fun refreshNetworkState() {
        val wifi = connectivity?.activeNetwork?.let { n ->
            connectivity.getNetworkCapabilities(n)?.let { c ->
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                    c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } == true

        val bt = runCatching {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        }.getOrDefault(false)

        _state.update { it.copy(wifiConnected = wifi, bluetoothOn = bt) }
        if (wifi) refreshWeather()
    }

    private fun applyBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        _state.update { it.copy(batteryPercent = pct, charging = charging) }
    }

    private fun startClockLoop() = viewModelScope.launch {
        var lastRx = TrafficStats.getTotalRxBytes()
        var lastTx = TrafficStats.getTotalTxBytes()
        var lastT = SystemClock.elapsedRealtime()
        while (isActive) {
            val now = LocalDateTime.now()
            val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val t = SystemClock.elapsedRealtime()
            val dt = (t - lastT).coerceAtLeast(1)
            val supported = rx != TrafficStats.UNSUPPORTED.toLong() && tx != TrafficStats.UNSUPPORTED.toLong()
            val down = if (supported) ((rx - lastRx) * 1000 / dt).coerceAtLeast(0) else 0
            val up = if (supported) ((tx - lastTx) * 1000 / dt).coerceAtLeast(0) else 0
            lastRx = rx; lastTx = tx; lastT = t
            _state.update {
                it.copy(
                    time = now.format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault())),
                    date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.getDefault())),
                    downBytesPerSec = down,
                    upBytesPerSec = up
                )
            }
            delay(1000)
        }
    }

    fun refreshWeather() {
        if (_state.value.weather.loading) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(weather = it.weather.copy(loading = true)) }
            val result = runCatching { WeatherRepository.fetch() }.getOrNull()
            _state.update {
                it.copy(
                    weather = result ?: WeatherState(location = "Weather unavailable"),
                )
            }
        }
    }

    override fun onCleared() {
        runCatching { ctx.unregisterReceiver(batteryReceiver) }
        runCatching { ctx.unregisterReceiver(bluetoothReceiver) }
        runCatching { connectivity?.unregisterNetworkCallback(networkCallback) }
        super.onCleared()
    }
}

private object WeatherRepository {
    fun fetch(): WeatherState {
        val geo = getJson("https://ipapi.co/json/") ?: return WeatherState(location = "Internet location unavailable")
        val lat = geo.optDouble("latitude", Double.NaN)
        val lon = geo.optDouble("longitude", Double.NaN)
        val city = listOf(geo.optString("city"), geo.optString("region"))
            .filter { it.isNotBlank() }.joinToString(", ")
            .ifBlank { "Current location" }
        if (!lat.isFinite() || !lon.isFinite()) return WeatherState(location = city)

        val weather = getJson(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto"
        ) ?: return WeatherState(location = city)
        val current = weather.optJSONObject("current") ?: return WeatherState(location = city)
        val temp = current.optDouble("temperature_2m", Double.NaN)
        val code = current.optInt("weather_code", -1)
        return WeatherState(
            temperature = if (temp.isFinite()) "${temp.toInt()}°C" else "--°",
            location = city,
            description = weatherDescription(code)
        )
    }

    private fun getJson(url: String): JSONObject? {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000
            readTimeout = 7000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (c.responseCode !in 200..299) null
            else JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally { c.disconnect() }
    }

    private fun weatherDescription(code: Int) = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Showers"
        95, 96, 99 -> "Storm"
        else -> ""
    }
}
