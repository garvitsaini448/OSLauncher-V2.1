package com.example.oslauncher

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val statusVm: StatusViewModel by viewModels()
    private val appsVm: AppsViewModel by viewModels()
    private val musicVm: MusicViewModel by viewModels()
    private val searchVm: SearchViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            musicVm.load()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )

        requestMediaPermissions()
        musicVm.load()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val status by statusVm.state.collectAsStateWithLifecycle()
                val apps by appsVm.apps.collectAsStateWithLifecycle()
                val music by musicVm.state.collectAsStateWithLifecycle()
                val results by searchVm.results.collectAsStateWithLifecycle()
                var query by remember { mutableStateOf("") }

                BackHandler(enabled = true) { }

                HomeScreen(
                    status = status,
                    apps = apps,
                    music = music,
                    searchResults = results,
                    searchQuery = query,
                    actions = HomeActions(
                        onLaunch = ::launchApp,
                        uninstallApp = ::uninstallApp,
                        openAppInfo = ::openAppInfo,
                        restoreLauncher = ::restoreDefaultLauncher,
                        openUri = ::openUri,
                        webSearch = ::webSearch
                    ),
                    onSearch = {
                        query = it
                        searchVm.search(it, apps)
                    },
                    onMusicPlayPause = musicVm::toggle,
                    onMusicNext = musicVm::next,
                    onMusicPrevious = musicVm::previous,
                    onMusicSeek = musicVm::seekTo,
                    onRefreshWeather = statusVm::refreshWeather
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        appsVm.refresh()
    }

    private fun requestMediaPermissions() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 33 -> arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO
            )
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            toast("Cannot open ${app.label}")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    private fun uninstallApp(app: AppEntry) {
        if (!app.canUninstall) {
            toast("${app.label} is a system app and can't be uninstalled")
            return
        }
        safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    }

    private fun openAppInfo(app: AppEntry) {
        safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
    }

    private fun openUri(uri: Uri) {
        safeStart(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    private fun webSearch(query: String, youtube: Boolean) {
        if (query.isBlank()) return
        val encoded = Uri.encode(query)
        val url = if (youtube) {
            "https://www.youtube.com/results?search_query=$encoded"
        } else {
            "https://www.google.com/search?q=$encoded"
        }
        safeStart(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun restoreDefaultLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            safeStart(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            toast("Action not available on this device")
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
