package com.example.oslauncher

import android.app.Application
import android.content.ContentUris
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

data class MusicTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: android.net.Uri,
    val albumArt: Bitmap? = null
)

data class MusicState(
    val track: MusicTrack? = null,
    val isPlaying: Boolean = false,
    val position: Int = 0,
    val duration: Int = 0,
    val available: Boolean = false
)

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val _state = MutableStateFlow(MusicState())
    val state = _state.asStateFlow()
    private var tracks = emptyList<MusicTrack>()
    private var index = 0
    private var player: MediaPlayer? = null
    private var progressJob: Job? = null

    fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            val loaded = runCatching {
                context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                    null,
                    "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { c ->
                    buildList {
                        while (c.moveToNext()) {
                            val id = c.getLong(0)
                            add(
                                MusicTrack(
                                    id,
                                    c.getString(1).orEmpty().ifBlank { "Unknown song" },
                                    c.getString(2).orEmpty().ifBlank { "Unknown artist" },
                                    ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                                )
                            )
                        }
                    }
                }.orEmpty()
            }.getOrDefault(emptyList())

            tracks = loaded
            if (loaded.isNotEmpty()) {
                index = index.coerceIn(0, loaded.lastIndex)
                val first = loaded[index]
                val art = loadAlbumArt(first.uri)
                tracks = loaded.toMutableList().also { list ->
                    list[index] = first.copy(albumArt = art)
                }
                withContext(Dispatchers.Main) { select(index, autoplay = false) }
            } else {
                _state.value = MusicState(available = false)
            }
        }
    }

    fun toggle() {
        val p = player ?: run {
            if (tracks.isNotEmpty()) select(index, true)
            return
        }
        if (p.isPlaying) p.pause() else p.start()
        _state.update { it.copy(isPlaying = p.isPlaying) }
    }

    fun next() {
        if (tracks.isEmpty()) return
        index = (index + 1) % tracks.size
        select(index, true)
    }

    fun previous() {
        if (tracks.isEmpty()) return
        if ((player?.currentPosition ?: 0) > 3000) {
            seekTo(0)
            return
        }
        index = (index - 1 + tracks.size) % tracks.size
        select(index, true)
    }

    fun seekTo(positionMs: Int) {
        player?.seekTo(positionMs.coerceIn(0, player?.duration ?: 0))
        _state.update { it.copy(position = positionMs) }
    }

    private fun select(newIndex: Int, autoplay: Boolean) {
        if (tracks.isEmpty()) return
        index = newIndex.coerceIn(0, tracks.lastIndex)
        player?.release()
        val track = tracks[index]
        if (track.albumArt == null) {
            viewModelScope.launch(Dispatchers.IO) {
                val art = loadAlbumArt(track.uri)
                if (art != null && index in tracks.indices && tracks[index].id == track.id) {
                    tracks = tracks.toMutableList().also { it[index] = track.copy(albumArt = art) }
                    _state.update { it.copy(track = track.copy(albumArt = art)) }
                }
            }
        }
        val p = MediaPlayer()
        player = p
        p.setAudioStreamType(AudioManager.STREAM_MUSIC)
        p.setOnPreparedListener {
            _state.value = MusicState(track, autoplay, 0, it.duration, true)
            if (autoplay) it.start()
        }
        p.setOnCompletionListener {
            next()
        }
        p.setOnErrorListener { _, _, _ ->
            _state.update { it.copy(isPlaying = false) }
            true
        }
        runCatching { p.setDataSource(context, track.uri); p.prepareAsync() }
            .onFailure {
                p.release()
                _state.value = MusicState(track, false, 0, 0, true)
            }
    }

    private fun loadAlbumArt(uri: android.net.Uri): Bitmap? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture?.let { bytes ->
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        } finally {
            retriever.release()
        }
    }.getOrNull()

    private fun startProgress() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (isActive) {
                val p = player
                if (p != null) {
                    _state.update {
                        it.copy(position = p.currentPosition, duration = p.duration.coerceAtLeast(0), isPlaying = p.isPlaying)
                    }
                }
                delay(400)
            }
        }
    }

    init { startProgress() }

    override fun onCleared() {
        progressJob?.cancel()
        player?.release()
        super.onCleared()
    }
}
