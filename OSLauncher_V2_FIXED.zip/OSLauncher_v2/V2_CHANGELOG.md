# OSLauncher V2 change log

Based on the supplied OSLauncher V1 ZIP.

### UI
- Replaced the V1 category cards with Windows/Start-inspired tile folders.
- Added a swipe-up app drawer.
- Kept long-press App Info / Uninstall behavior.
- Removed the V1 home-screen Restore One UI FAB.
- Added Launcher Settings containing Restore One UI Home.

### Status
- Wi-Fi is now icon-only and color-coded green/red.
- Added weather + temperature + approximate location.
- Retained clock/date, battery, traffic and Bluetooth.

### Search
- Added a persistent bottom search bar.
- Searches installed apps and MediaStore-indexed music/video/files.
- Added Web Search and YouTube fallback actions.

### Music
- Added home music controls.
- Added album art extraction when audio files contain embedded artwork.
- Added previous/play-next and seek bar.

### Build
- Version 2.0 / versionCode 2.
- Added media/internet permissions.
- Added `.github/workflows/android.yml` using JDK 17 and Gradle 8.7.
